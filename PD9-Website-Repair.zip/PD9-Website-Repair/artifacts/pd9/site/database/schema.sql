-- PD9 Crime Investigation Platform - Database Schema
-- PostgreSQL / Supabase compatible
-- Run this migration on your production database.

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================
-- 1. USERS
-- ============================================
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  username VARCHAR(100) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(255),
  role VARCHAR(20) DEFAULT 'user' CHECK (role IN ('user', 'admin')),
  xp INTEGER DEFAULT 0,
  level INTEGER DEFAULT 1,
  is_banned BOOLEAN DEFAULT FALSE,
  banned_reason TEXT,
  vip_level VARCHAR(50) DEFAULT 'free',
  vip_expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- 2. CASES
-- ============================================
CREATE TABLE IF NOT EXISTS cases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title_ar VARCHAR(255) NOT NULL,
  title_en VARCHAR(255),
  description_ar TEXT,
  description_en TEXT,
  story_ar TEXT,
  story_en TEXT,
  difficulty VARCHAR(20) DEFAULT 'medium' CHECK (difficulty IN ('easy', 'medium', 'hard', 'expert')),
  is_vip BOOLEAN DEFAULT FALSE,
  is_active BOOLEAN DEFAULT TRUE,
  xp_reward INTEGER DEFAULT 100,
  cover_image_url TEXT,
  cinematic_intro_url TEXT,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- 3. CASE STAGES / PHASES
-- ============================================
CREATE TABLE IF NOT EXISTS stages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id UUID NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
  stage_number INTEGER NOT NULL,
  title_ar VARCHAR(255) NOT NULL,
  title_en VARCHAR(255),
  puzzle_type VARCHAR(50) NOT NULL,
  content_ar JSONB DEFAULT '{}',
  content_en JSONB DEFAULT '{}',
  correct_answer JSONB DEFAULT '{}',
  hints JSONB DEFAULT '[]',
  xp_reward INTEGER DEFAULT 25,
  is_locked BOOLEAN DEFAULT TRUE,
  order_index INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (case_id, stage_number)
);

-- ============================================
-- 4. USER PROGRESS (saved investigation state)
-- ============================================
CREATE TABLE IF NOT EXISTS user_progress (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  case_id UUID NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
  stage_id UUID REFERENCES stages(id) ON DELETE SET NULL,
  current_stage INTEGER DEFAULT 1,
  completed_stages JSONB DEFAULT '[]',
  collected_evidence JSONB DEFAULT '[]',
  case_completed BOOLEAN DEFAULT FALSE,
  case_result VARCHAR(50),
  total_xp INTEGER DEFAULT 0,
  started_at TIMESTAMPTZ DEFAULT NOW(),
  last_updated TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (user_id, case_id)
);

-- ============================================
-- 5. VIP ACTIVATION CODES
-- ============================================
CREATE TABLE IF NOT EXISTS vip_codes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code VARCHAR(100) UNIQUE NOT NULL,
  description_ar TEXT,
  description_en TEXT,
  vip_level VARCHAR(50) NOT NULL,
  max_uses INTEGER,
  current_uses INTEGER DEFAULT 0,
  single_use_per_user BOOLEAN DEFAULT FALSE,
  expires_at TIMESTAMPTZ,
  is_active BOOLEAN DEFAULT TRUE,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  revoked_at TIMESTAMPTZ,
  revoked_by UUID REFERENCES users(id)
);

-- Track code usage per user (for single-use-per-user codes)
CREATE TABLE IF NOT EXISTS vip_code_usage (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code_id UUID NOT NULL REFERENCES vip_codes(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  used_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (code_id, user_id)
);

-- ============================================
-- 6. ACHIEVEMENTS / BADGES
-- ============================================
CREATE TABLE IF NOT EXISTS achievements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name_ar VARCHAR(255) NOT NULL,
  name_en VARCHAR(255),
  description_ar TEXT,
  description_en TEXT,
  badge_icon VARCHAR(100),
  xp_reward INTEGER DEFAULT 0,
  condition_type VARCHAR(50),
  condition_value JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- 7. USER ACHIEVEMENTS (unlocked badges)
-- ============================================
CREATE TABLE IF NOT EXISTS user_achievements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  achievement_id UUID NOT NULL REFERENCES achievements(id) ON DELETE CASCADE,
  unlocked_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (user_id, achievement_id)
);

-- ============================================
-- 8. ADMIN AUDIT LOGS
-- ============================================
CREATE TABLE IF NOT EXISTS audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id UUID REFERENCES users(id),
  action VARCHAR(100) NOT NULL,
  target_type VARCHAR(50),
  target_id UUID,
  details JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- 9. NOTIFICATIONS
-- ============================================
CREATE TABLE IF NOT EXISTS notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  title_ar VARCHAR(255),
  title_en VARCHAR(255),
  message_ar TEXT,
  message_en TEXT,
  type VARCHAR(50) DEFAULT 'info',
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- INDEXES for performance
-- ============================================
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_cases_vip ON cases(is_vip);
CREATE INDEX IF NOT EXISTS idx_stages_case ON stages(case_id);
CREATE INDEX IF NOT EXISTS idx_progress_user ON user_progress(user_id);
CREATE INDEX IF NOT EXISTS idx_progress_case ON user_progress(case_id);
CREATE INDEX IF NOT EXISTS idx_vip_codes_code ON vip_codes(code);
CREATE INDEX IF NOT EXISTS idx_audit_admin ON audit_logs(admin_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id);

-- ============================================
-- SEED DATA: Demo admin user (password: AdminPD9!2026)
-- ============================================
INSERT INTO users (email, username, password_hash, full_name, role)
VALUES (
  'admin@pd9.local',
  'pd9admin',
  crypt('AdminPD9!2026', gen_salt('bf')),
  'مدير النظام',
  'admin'
) ON CONFLICT (email) DO NOTHING;

-- ============================================
-- SEED DATA: Sample Case 1 - "The Silent Studio"
-- ============================================
INSERT INTO cases (title_ar, title_en, description_ar, description_en, story_ar, story_en, difficulty, is_vip, xp_reward)
VALUES (
  'الاستوديو الصامت',
  'The Silent Studio',
  'جريمة قتل غامضة في استوديو تسجيل ليلي. لا شهود، لا أدلة واضحة، فقط تسجيل صوتي غامض.',
  'A mysterious murder at a night recording studio. No witnesses, no clear evidence, only a cryptic audio recording.',
  'في ليلة ممطرة، تم العثور على مغني مشهور مقتولاً في استوديو التسجيل الخاص به. الباب مغلق من الداخل، والساعة تتوقف عند الساعة الثالثة صباحاً. أنت المحقق المكلف بالقضية.',
  'On a rainy night, a famous singer was found murdered in his private recording studio. The door was locked from the inside, and the clock stopped at 3:00 AM. You are the detective assigned to the case.',
  'medium',
  FALSE,
  150
) RETURNING id;

-- Note: Stages for this case would be added via the Admin Dashboard or subsequent migrations.

-- ============================================
-- ROW LEVEL SECURITY (enable for production)
-- ============================================
-- ALTER TABLE users ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE cases ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE stages ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE user_progress ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE vip_codes ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE vip_code_usage ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE achievements ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE user_achievements ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
