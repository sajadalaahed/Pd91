/* ============================================
   PD9 - Netlify Function: admin
   Protected admin endpoints (role-based, server-side).
   Endpoints:
     GET    /admin/stats
     GET    /admin/users
     POST   /admin/users/:id/ban
     GET    /admin/vip-codes
     POST   /admin/vip-codes
     DELETE /admin/vip-codes/:id
     GET    /admin/cases
     POST   /admin/cases
     PUT    /admin/cases/:id
     DELETE /admin/cases/:id
   ============================================ */

const { verifyJwt, findUserById, store } = require('../lib/store');

function json(res, status, body) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.end(JSON.stringify(body));
}

function getToken(req) {
  const auth = req.headers.authorization || '';
  return auth.startsWith('Bearer ') ? auth.slice(7) : null;
}

function requireAdmin(req, res) {
  const token = getToken(req);
  if (!token) { res.writableEnded || json(res, 401, { message: 'تسجيل الدخول مطلوب' }); return false; }
  const payload = verifyJwt(token);
  if (!payload) { res.writableEnded || json(res, 401, { message: 'جلسة غير صالحة' }); return false; }
  const user = store.users.find(u => u.id === payload.userId);
  if (!user || user.role !== 'admin') { res.writableEnded || json(res, 403, { message: 'موقع مخصص للمشرفين فقط' }); return false; }
  return { user, payload };
}

async function handler(req, res) {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const path = url.searchParams.get('r') || url.pathname.replace(/\/$/, '');
  const method = req.method;

  if (method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    });
    res.end();
    return;
  }

  try {
    // ---------- GET /admin/stats ----------
    if (path === '/admin/stats' && method === 'GET') {
      const admin = requireAdmin(req, res);
      if (admin === false) return;
      const totalUsers = store.users.length;
      const totalCases = store.cases.length;
      const completedCases = store.progress.filter(p => p.case_completed).length;
      const vipUsers = store.users.filter(u => u.vip_level !== 'free').length;
      return json(res, 200, {
        total_users: totalUsers,
        total_cases: totalCases,
        completed_cases: completedCases,
        vip_users: vipUsers,
        top_users: store.users
          .filter(u => u.role === 'user')
          .sort((a, b) => (b.xp || 0) - (a.xp || 0))
          .slice(0, 10)
          .map(u => ({ username: u.username, full_name: u.full_name, xp: u.xp, level: u.level })),
      });
    }

    // ---------- GET /admin/users ----------
    if (path === '/admin/users' && method === 'GET') {
      const admin = requireAdmin(req, res);
      if (admin === false) return;
      const users = store.users.map(u => ({
        id: u.id, email: u.email, username: u.username, full_name: u.full_name,
        role: u.role, xp: u.xp, level: u.level, vip_level: u.vip_level,
        is_banned: u.is_banned || false, created_at: u.created_at,
      }));
      return json(res, 200, { users });
    }

    // ---------- POST /admin/users/:id/ban ----------
    const banMatch = path.match(/^\/admin\/users\/([^/]+)\/ban$/);
    if (banMatch && method === 'POST') {
      const admin = requireAdmin(req, res);
      if (admin === false) return;
      const userId = banMatch[1];
      let body;
      try { body = JSON.parse(await new Promise(r => { let d=''; req.on('data',c=>d+=c); req.on('end',()=>r(d)); })); } catch { return json(res,400,{message: 'بيانات غير صالحة'}); }

      const user = store.users.find(u => u.id === userId);
      if (!user) return json(res, 404, { message: 'المستخدم غير موجود' });
      if (user.role === 'admin') return json(res, 403, { message: 'لا يمكن حظر مسؤول آخر' });

      user.is_banned = true;
      user.banned_reason = body.reason || 'غير محدد';
      store.auditLogs.push({
        admin_id: admin.user.id, action: 'ban_user', target_type: 'user',
        target_id: userId, details: { reason: user.banned_reason },
        created_at: new Date().toISOString(),
      });
      return json(res, 200, { message: 'تم حظر المستخدم', user });
    }

    // ---------- GET /admin/vip-codes ----------
    if (path === '/admin/vip-codes' && method === 'GET') {
      const admin = requireAdmin(req, res);
      if (admin === false) return;
      return json(res, 200, { codes: store.vipCodes.map(c => ({
        id: c.id, code: c.code, description_ar: c.description_ar,
        vip_level: c.vip_level, max_uses: c.max_uses, current_uses: c.current_uses,
        single_use_per_user: c.single_use_per_user, expires_at: c.expires_at,
        is_active: c.is_active, created_at: c.created_at, revoked_at: c.revoked_at,
      })) });
    }

    // ---------- POST /admin/vip-codes ----------
    if (path === '/admin/vip-codes' && method === 'POST') {
      const admin = requireAdmin(req, res);
      if (admin === false) return;
      let body;
      try { body = JSON.parse(await new Promise(r => { let d=''; req.on('data',c=>d+=c); req.on('end',()=>r(d)); })); } catch { return json(res,400,{message: 'بيانات غير صالحة'}); }

      const { code, description_ar, vip_level, max_uses, single_use_per_user, expires_at } = body;
      if (!code || !vip_level) return json(res, 400, { message: 'الكود والمستوى مطلوبان' });

      const newCode = {
        id: 'vip-' + crypto.randomBytes(4).toString('hex'),
        code: code.toUpperCase(),
        description_ar: description_ar || '',
        vip_level,
        max_uses: max_uses ? parseInt(max_uses) : undefined,
        current_uses: 0,
        single_use_per_user: single_use_per_user === true,
        expires_at: expires_at || null,
        is_active: true,
        created_by: admin.user.id,
        created_at: new Date().toISOString(),
      };
      store.vipCodes.push(newCode);
      store.auditLogs.push({
        admin_id: admin.user.id, action: 'create_vip_code', target_type: 'vip_code',
        target_id: newCode.id, details: { code: newCode.code },
        created_at: new Date().toISOString(),
      });
      return json(res, 201, { message: 'تم إنشاء كود VIP', code: newCode });
    }

    // ---------- DELETE /admin/vip-codes/:id ----------
    const delCodeMatch = path.match(/^\/admin\/vip-codes\/([^/]+)$/);
    if (delCodeMatch && method === 'DELETE') {
      const admin = requireAdmin(req, res);
      if (admin === false) return;
      const codeId = delCodeMatch[1];
      const idx = store.vipCodes.findIndex(c => c.id === codeId);
      if (idx === -1) return json(res, 404, { message: 'الكود غير موجود' });

      store.vipCodes[idx].is_active = false;
      store.vipCodes[idx].revoked_at = new Date().toISOString();
      store.vipCodes[idx].revoked_by = admin.user.id;
      store.auditLogs.push({
        admin_id: admin.user.id, action: 'revoke_vip_code', target_type: 'vip_code',
        target_id: codeId, details: {}, created_at: new Date().toISOString(),
      });
      return json(res, 200, { message: 'تم إلغاء الكود' });
    }

    // ---------- Cases CRUD ----------
    if (path === '/admin/cases' && method === 'GET') {
      const admin = requireAdmin(req, res);
      if (admin === false) return;
      return json(res, 200, { cases: store.cases.map(c => ({
        id: c.id, title_ar: c.title_ar, title_en: c.title_en,
        description_ar: c.description_ar, difficulty: c.difficulty,
        is_vip: c.is_vip, xp_reward: c.xp_reward, created_at: c.created_at,
      })) });
    }

    if (path === '/admin/cases' && method === 'POST') {
      const admin = requireAdmin(req, res);
      if (admin === false) return;
      let body;
      try { body = JSON.parse(await new Promise(r => { let d=''; req.on('data',c=>d+=c); req.on('end',()=>r(d)); })); } catch { return json(res,400,{message: 'بيانات غير صالحة'}); }

      const newCase = {
        id: 'c-' + crypto.randomBytes(4).toString('hex'),
        title_ar: body.title_ar, title_en: body.title_en,
        description_ar: body.description_ar, description_en: body.description_en,
        story_ar: body.story_ar, story_en: body.story_en,
        difficulty: body.difficulty || 'medium', is_vip: body.is_vip === true,
        xp_reward: parseInt(body.xp_reward) || 100,
        cover_image_url: body.cover_image_url || '',
        created_at: new Date().toISOString(),
      };
      store.cases.push(newCase);
      return json(res, 201, { message: 'تم إضافة القضية', case: newCase });
    }

    const caseMatch = path.match(/^\/admin\/cases\/([^/]+)$/);
    if (caseMatch && method === 'PUT') {
      const admin = requireAdmin(req, res);
      if (admin === false) return;
      const caseId = caseMatch[1];
      const c = store.cases.find(x => x.id === caseId);
      if (!c) return json(res, 404, { message: 'القضية غير موجودة' });
      let body;
      try { body = JSON.parse(await new Promise(r => { let d=''; req.on('data',c=>d+=c); req.on('end',()=>r(d)); })); } catch { return json(res,400,{message: 'بيانات غير صالحة'}); }
      Object.assign(c, {
        title_ar: body.title_ar !== undefined ? body.title_ar : c.title_ar,
        description_ar: body.description_ar !== undefined ? body.description_ar : c.description_ar,
        difficulty: body.difficulty || c.difficulty,
        is_vip: body.is_vip !== undefined ? body.is_vip : c.is_vip,
        xp_reward: body.xp_reward !== undefined ? parseInt(body.xp_reward) : c.xp_reward,
      });
      return json(res, 200, { message: 'تم تحديث القضية', case: c });
    }

    if (caseMatch && method === 'DELETE') {
      const admin = requireAdmin(req, res);
      if (admin === false) return;
      const caseId = caseMatch[1];
      const idx = store.cases.findIndex(c => c.id === caseId);
      if (idx === -1) return json(res, 404, { message: 'القضية غير موجودة' });
      store.cases.splice(idx, 1);
      store.stages = store.stages.filter(s => s.case_id !== caseId);
      return json(res, 200, { message: 'تم حذف القضية' });
    }

    return json(res, 404, { message: 'نقطة النهاية غير موجودة' });
  } catch (e) {
    console.error('[admin]', e);
    return json(res, 500, { message: 'خطأ في الخادم' });
  }
}

module.exports = { handler };
