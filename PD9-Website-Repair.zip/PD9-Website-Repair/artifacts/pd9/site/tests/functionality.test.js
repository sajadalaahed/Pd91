/* ============================================
   PD9 - Functionality Tests (frontend smoke tests)
   هذه اختبارات أولية للتأكد من تحميل العناصر الأساسية.
   تُRun في المتصفح بعد فتح index.html.
   ============================================ */

(function () {
  var passed = 0;
  var failed = 0;

  function assert(condition, name) {
    if (condition) {
      passed++;
      console.log('[PASS]', name);
    } else {
      failed++;
      console.error('[FAIL]', name);
    }
  }

  // Wait for DOM
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', runTests);
  } else {
    runTests();
  }

  function runTests() {
    // 1. Core globals exist
    assert(typeof window.PD9_CONFIG === 'object', 'PD9_CONFIG موجود');
    assert(typeof window.PD9Audio === 'object', 'PD9Audio موجود');
    assert(typeof window.PD9API === 'object', 'PD9API موجود');
    assert(typeof window.PD9Auth === 'object', 'PD9Auth موجود');
    assert(typeof window.PD9Cases === 'object', 'PD9Cases موجود');
    assert(typeof window.PD9UI === 'object', 'PD9UI موجود');

    // 2. DOM elements exist
    assert(document.getElementById('navbar'), 'الشريط العلوي موجود');
    assert(document.getElementById('hero'), document.getElementById('.hero') || document.querySelector('.hero') ? true : false, 'قسم الصفحة الرئيسية موجود');
    assert(document.getElementById('cases-grid'), 'شبكة القضايا موجودة');
    assert(document.getElementById('case-player'), 'مشغل القضايا موجود');
    assert(document.getElementById('auth-modal'), 'نافذة تسجيل الدخول موجودة');
    assert(document.getElementById('toast'), 'إشعار التنبيه موجود');

    // 3. Buttons are not dummy (have handlers or purpose)
    var loginForm = document.getElementById('login-form');
    assert(loginForm, 'نموذج تسجيل الدخول موجود');
    var registerForm = document.getElementById('register-form');
    assert(registerForm, 'نموذج التسجيل موجود');
    var contactForm = document.getElementById('contact-form');
    assert(contactForm, 'نموذج التواصل موجود');

    // 4. RTL direction
    assert(document.documentElement.dir === 'rtl', 'الاتجاه من اليمين لليسار (RTL)');

    // 5. Theme colors (dark)
    var bg = getComputedStyle(document.body).backgroundColor;
    assert(bg.indexOf('0') !== -1 || bg.indexOf('10') !== -1 || bg === 'rgb(10, 10, 10)', 'السمة داكنة (backgroud)');

    console.log('\n==============================');
    console.log('النتائج: نجح ' + passed + '، فشل ' + failed);
    console.log('==============================\n');

    if (failed > 0) {
      alert('فشل ' + failed + ' اختباراً. راجع وحدة التحكم (Console).');
    } else {
      alert('جميع الاختبارات الأساسية نجحت!');
    }
  }
})();
