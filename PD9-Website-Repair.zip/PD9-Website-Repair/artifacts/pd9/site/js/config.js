/* ============================================
   PD9 - Configuration
   ============================================ */

const PD9_CONFIG = {
  appName: 'PD9',
  appNameAr: 'منصة التحقيقات الجنائية',
  version: '1.0.0',
  // Shared PD9 API
  apiBase: '/api/pd9',
  // Demo mode flag - set true to run without backend (for preview)
  demoMode: false,
  // Local storage keys
  storage: {
    token: 'pd9_token',
    user: 'pd9_user',
    progress: 'pd9_progress',
    soundEnabled: 'pd9_sound',
    volume: 'pd9_volume',
  },
  // Puzzle types
  puzzleTypes: [
    'image_analysis',
    'fingerprint',
    'cctv',
    'cipher',
    'timeline',
    'contradiction',
    'evidence_link',
    'interrogation',
    'verdict',
    'forensic_report'
  ],
  // Audio settings
  audio: {
    enabled: true,
    volume: 0.5,
  },
};

window.PD9_CONFIG = PD9_CONFIG;
