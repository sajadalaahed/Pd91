/* ============================================
   PD9 - Detective Dashboard
   Notebook, evidence bag, progress, leaderboard
   ============================================ */

const PD9Detective = (() => {
  const dashboardEl = document.getElementById('dashboard');
  const notebookEl = document.getElementById('cp-sidebar');

  async function loadDashboard() {
    if (!PD9Auth.isAuthenticated()) return;
    try {
      const progress = await PD9API.getProgress();
      renderNotebook(progress);
      renderLeaderboard();
    } catch (e) {
      console.error('[PD9Detective] load failed', e);
      renderNotebook({});
    }
  }

  function renderNotebook(progress) {
    if (!notebookEl) return;
    let html = '<div class="cp-section"><h4>دفتر الملاحظات</h4>';
    const entries = Object.entries(progress).map(([cid, p]) => ({
      id: cid, ...p
    }));

    if (!entries.length) {
      html += '<div class="notebook-item"><div class="item-text">لا توجد ملاحظات بعد. ابدأ تحقيقاً لتسجيل أدلتك.</div></div>';
    } else {
      entries.forEach(e => {
        html += `
          <div class="notebook-item">
            <div class="item-title">${e.case_id || 'قضية'}</div>
            <div class="item-text">المرحلة الحالية: ${e.current_stage || 1} | الأدلة المجمعة: ${e.collected_evidence ? e.collected_evidence.length : 0}</div>
          </div>
        `;
      });
    }
    html += '</div>';

    // Evidence bag
    html += `<div class="cp-section"><h4>حقيبة الأدلة</h4>`;
    const allEvidence = Object.values(progress).flatMap(p => p.collected_evidence || []);
    if (!allEvidence.length) {
      html += '<div class="notebook-item"><div class="item-text">حقيبة الأدلة فارغة.</div></div>';
    } else {
      allEvidence.forEach(ev => {
        html += `<div class="notebook-item"><div class="item-title">${ev.name || 'أدلة'}</div><div class="item-text">${ev.note || ''}</div></div>`;
      });
    }
    html += '</div>';

    // XP
    const user = PD9Auth.getUser();
    const xp = user ? user.xp : 0;
    const level = user ? user.level : 1;
    html += `
      <div class="cp-section">
        <h4>تقييم المحقق</h4>
        <div style="margin-bottom:0.5rem;">المستوى ${level}</div>
        <div class="xp-bar"><div class="xp-fill" style="width:${Math.min(100, xp % 100)}%"></div></div>
        <div style="text-align:right;font-size:0.8rem;color:var(--text-muted);margin-top:0.25rem;">${xp} XP</div>
      </div>
    `;

    notebookEl.innerHTML = html;
  }

  async function renderLeaderboard() {
    try {
      const stats = await PD9API.adminStats();
      const users = stats.top_users || [];
      const tbody = document.getElementById('leaderboard-body');
      if (!tbody) return;
      tbody.innerHTML = users.map((u, i) => `
        <tr>
          <td class="leaderboard-rank">${i + 1}</td>
          <td class="leaderboard-name">${u.username || u.full_name}</td>
          <td>${u.xp || 0}</td>
          <td>${u.level || 1}</td>
        </tr>
      `).join('');
    } catch (e) {
      // leaderboard may not be available
    }
  }

  return { loadDashboard, renderNotebook };
})();

window.PD9Detective = PD9Detective;
