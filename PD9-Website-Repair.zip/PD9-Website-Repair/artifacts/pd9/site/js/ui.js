/* ============================================
   PD9 - UI Helpers
   Toast, modals, loading, nav
   ============================================ */

const PD9UI = (() => {
  const toastEl = document.getElementById('toast');
  let toastTimer;

  function showToast(message, type = 'info') {
    if (!toastEl) return;
    toastEl.textContent = message;
    toastEl.className = 'toast show ' + (type === 'success' ? 'success' : type === 'error' ? 'error' : '');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      toastEl.classList.remove('show');
    }, 3000);
  }

  function showLoading(show) {
    const el = document.getElementById('loading-overlay');
    if (!el) return;
    if (show) el.classList.remove('hidden');
    else el.classList.add('hidden');
  }

  // Auth modal
  const authModal = document.getElementById('auth-modal');
  const loginForm = document.getElementById('login-form');
  const registerForm = document.getElementById('register-form');
  const authTabs = document.querySelectorAll('.auth-tab');
  const authPanels = document.querySelectorAll('.auth-panel');
  const closeAuth = document.getElementById('auth-modal-close');
  const userBtn = document.getElementById('user-btn');

  function openAuthModal() {
    if (authModal) authModal.classList.remove('hidden');
    PD9Audio.play('click');
  }

  function closeAuthModal() {
    if (authModal) authModal.classList.add('hidden');
  }

  function switchAuthTab(tab) {
    authTabs.forEach(t => t.classList.toggle('active', t.dataset.tab === tab));
    authPanels.forEach(p => p.classList.toggle('active', p.id === `panel-${tab}`));
  }

  async function handleLogin(e) {
    e.preventDefault();
    const fd = new FormData(loginForm);
    const identifier = fd.get('identifier');
    const password = fd.get('password');
    showLoading(true);
    try {
      await PD9Auth.login(identifier, password);
      closeAuthModal();
      loginForm.reset();
      showToast('تم تسجيل الدخول بنجاح', 'success');
      updateNavUser();
      PD9Detective.loadDashboard();
    } catch (e) {
      showToast(e.message || 'فشل تسجيل الدخول', 'error');
    } finally {
      showLoading(false);
    }
  }

  async function handleRegister(e) {
    e.preventDefault();
    const fd = new FormData(registerForm);
    const payload = {
      full_name: fd.get('full_name'),
      username: fd.get('username'),
      email: fd.get('email'),
      password: fd.get('password'),
    };
    showLoading(true);
    try {
      await PD9Auth.register(payload);
      closeAuthModal();
      registerForm.reset();
      showToast('تم إنشاء الحساب بنجاح', 'success');
      updateNavUser();
      PD9Detective.loadDashboard();
    } catch (e) {
      showToast(e.message || 'فشل إنشاء الحساب', 'error');
    } finally {
      showLoading(false);
    }
  }

  function updateNavUser() {
    const user = PD9Auth.getUser();
    const btn = document.getElementById('user-btn');
    if (!btn) return;
    if (user) {
      btn.textContent = user.username || user.full_name || 'الحساب';
      btn.classList.add('logged-in');
      btn.onclick = () => { location.href = 'profile.html'; };
    } else {
      btn.textContent = 'تسجيل الدخول';
      btn.classList.remove('logged-in');
      btn.onclick = openAuthModal;
    }
  }

  // Mobile nav toggle
  const navToggle = document.getElementById('nav-toggle');
  const navMenu = document.getElementById('nav-menu');
  if (navToggle && navMenu) {
    navToggle.onclick = () => navMenu.classList.toggle('open');
    // Close on link click
    navMenu.querySelectorAll('.nav-link').forEach(l => {
      l.onclick = () => navMenu.classList.remove('open');
    });
  }

  // Sound toggle
  const soundBtn = document.getElementById('sound-toggle');
  if (soundBtn) {
    soundBtn.onclick = () => {
      const on = PD9Audio.toggle();
      soundBtn.querySelector('.sound-icon').textContent = on ? '🔊' : '🔇';
      PD9Audio.play('click');
    };
  }

  // Audio unlock overlay
  const unlockOverlay = document.getElementById('audio-unlock');
  const unlockBtn = document.getElementById('unlock-audio-btn');
  if (unlockBtn && unlockOverlay) {
    unlockBtn.onclick = async () => {
      await PD9Audio.init();
      await PD9Audio.preload();
      PD9Audio.startBg();
      unlockOverlay.classList.add('hidden');
      PD9Audio.play('unlock');
    };
  }

  // Contact form
  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    contactForm.onsubmit = (e) => {
      e.preventDefault();
      showToast('تم إرسال رسالتك. سنتواصل معك قريباً.', 'success');
      contactForm.reset();
    };
  }

  return { showToast, showLoading, openAuthModal, closeAuthModal, switchAuthTab, handleLogin, handleRegister, updateNavUser };
})();

window.PD9UI = PD9UI;
