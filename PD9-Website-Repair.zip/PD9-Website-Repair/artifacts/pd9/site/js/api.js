/* ============================================
   PD9 - Legacy API facade for the shared API.
   Preserves the PD9API interface used by the original UI.
   ============================================ */

const PD9API = (() => {
  const BASE = PD9_CONFIG.apiBase;

  function apiUrl(route) {
    return `${BASE}${route}`;
  }

  function getToken() {
    return localStorage.getItem(PD9_CONFIG.storage.token);
  }

  async function request(route, opts = {}) {
    const url = apiUrl(route);
    const headers = {
      'Content-Type': 'application/json',
      ...(opts.headers || {}),
    };
    const token = getToken();
    if (token) headers.Authorization = `Bearer ${token}`;

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 15000);

    try {
      const res = await fetch(url, {
        ...opts,
        headers,
        signal: controller.signal,
      });
      clearTimeout(timeout);

      let data = null;
      const ct = res.headers.get('content-type') || '';
      if (ct.includes('application/json')) {
        data = await res.json();
      } else {
        data = await res.text();
      }

      if (!res.ok) {
        const err = new Error(data.message || 'طلب فشل');
        err.status = res.status;
        err.data = data;
        throw err;
      }
      return data;
    } catch (e) {
      clearTimeout(timeout);
      if (e.name === 'AbortError') {
        const err = new Error('انتهت مهلة الطلب');
        err.status = 408;
        throw err;
      }
      throw e;
    }
  }

  // ----- Auth -----
  async function login(identifier, password) {
    return request('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ identifier, password }),
    });
  }

  async function register({ full_name, username, email, password }) {
    return request('/auth/register', {
      method: 'POST',
      body: JSON.stringify({ full_name, username, email, password }),
    });
  }

  async function logout() {
    try { await request('/auth/logout', { method: 'POST' }); } catch (e) {}
    localStorage.removeItem(PD9_CONFIG.storage.token);
    localStorage.removeItem(PD9_CONFIG.storage.user);
  }

  async function me() {
    return request('/auth/me');
  }

  // ----- Cases -----
  async function getCases() {
    return request('/cases');
  }

  async function adminListCases() {
    return request('/admin/cases');
  }

  async function getCase(id) {
    return request(`/cases/${id}`);
  }

  async function getStage(stageId) {
    return request(`/stages/${stageId}`);
  }

  async function submitStageAnswer(stageId, answer) {
    return request(`/stages/${stageId}/answer`, {
      method: 'POST',
      body: JSON.stringify(typeof answer === 'string' ? { answer } : answer),
    });
  }

  // ----- Progress -----
  async function getProgress() {
    const data = await request('/progress');
    return data && data.progress ? data.progress : data;
  }

  async function saveProgress(caseId, data) {
    return request('/progress', {
      method: 'POST',
      body: JSON.stringify({ case_id: caseId, ...data }),
    });
  }

  // ----- VIP -----
  async function redeemVipCode(code) {
    return request('/vip/redeem', {
      method: 'POST',
      body: JSON.stringify({ code }),
    });
  }

  async function getVipTiers() {
    return request('/vip/tiers');
  }

  // ----- Admin -----
  async function adminStats() {
    return request('/admin/stats');
  }

  async function adminListUsers() {
    return request('/admin/users');
  }

  async function adminBanUser(userId, reason) {
    return request(`/admin/users/${userId}/ban`, {
      method: 'POST',
      body: JSON.stringify({ reason }),
    });
  }

  async function adminCreateVipCode(payload) {
    return request('/admin/vip-codes', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  }

  async function adminListVipCodes() {
    return request('/admin/vip-codes');
  }

  async function adminRevokeVipCode(codeId) {
    return request(`/admin/vip-codes/${codeId}`, { method: 'DELETE' });
  }

  async function adminCreateCase(payload) {
    return request('/admin/cases', { method: 'POST', body: JSON.stringify(payload) });
  }

  async function adminUpdateCase(caseId, payload) {
    return request(`/admin/cases/${caseId}`, { method: 'PUT', body: JSON.stringify(payload) });
  }

  async function adminDeleteCase(caseId) {
    return request(`/admin/cases/${caseId}`, { method: 'DELETE' });
  }

  return {
    login, register, logout, me,
    getCases, adminListCases, getCase, getStage, submitStageAnswer,
    getProgress, saveProgress,
    redeemVipCode, getVipTiers,
    adminStats, adminListUsers, adminBanUser,
    adminCreateVipCode, adminListVipCodes, adminRevokeVipCode,
    adminCreateCase, adminUpdateCase, adminDeleteCase,
  };
})();

window.PD9API = PD9API;
