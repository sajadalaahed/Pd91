/* ============================================
   PD9 - Cases & Investigation Player
   يدعم جميع أنواع الألغاز الـ15 ونظام جمع الأدلة.
   ============================================ */

const PD9Cases = (() => {
  let cases = [];
  let currentCase = null;
  let currentStage = null;
  let progress = {};
  let collectedEvidence = []; // الأدلة المجمعة في القضية الحالية

  const caseEl = document.getElementById('case-player');
  const closeBtn = document.getElementById('case-player-close');
  const mainEl = document.getElementById('cp-main');
  const sidebarEl = document.getElementById('cp-sidebar');
  const progressFill = document.getElementById('cp-progress-fill');
  const progressPct = document.getElementById('cp-progress-pct');
  const caseTitleEl = document.getElementById('cp-case-title');
  const caseDescEl = document.getElementById('cp-case-desc');
  const hintBtn = document.getElementById('cp-btn-hint');
  const submitBtn = document.getElementById('cp-btn-submit');

  let currentAnswer = null;
  let currentHints = [];
  let hintIndex = 0;

  // ---------- Load cases list ----------
  async function loadCases() {
    try {
      const result = await PD9API.getCases();
      cases = Array.isArray(result) ? result : (result.cases || []);
      renderCasesGrid(cases);
      updateHeroStats();
    } catch (e) {
      console.error('[PD9Cases] load failed', e);
      cases = [];
      renderCasesGrid(cases);
      PD9UI.showToast('تعذر تحميل القضايا من الخادم', 'error');
    }
  }

  function getDemoCases() {
    return [
      {
        id: 'demo-1',
        title_ar: 'الاستوديو الصامت',
        title_en: 'The Silent Studio',
        description_ar: 'جريمة قتل غامضة في استوديو تسجيل ليلي.',
        difficulty: 'medium',
        is_vip: false,
        xp_reward: 150,
        stages: [],
      },
    ];
  }

  function renderCasesGrid(list) {
    const grid = document.getElementById('cases-grid');
    const empty = document.getElementById('cases-empty');
    if (!grid) return;
    grid.innerHTML = '';

    if (!list || list.length === 0) {
      if (empty) empty.classList.remove('hidden');
      return;
    }
    if (empty) empty.classList.add('hidden');

    list.forEach(c => {
      const card = document.createElement('div');
      card.className = `case-card${c.is_vip ? ' vip' : ''}`;
      const stageCount = c.stages ? c.stages.length : 0;
      card.innerHTML = `
        <div class="case-meta">
          <span>${c.difficulty}</span>
          ${c.xp_reward ? `<span>+${c.xp_reward} XP</span>` : ''}
          ${stageCount ? `<span>${stageCount} مرحلة</span>` : ''}
        </div>
        <h3>${c.title_ar}</h3>
        <p>${c.description_ar}</p>
        <div class="case-actions">
          <button class="btn btn-primary btn-full" onclick="PD9Cases.openCase('${c.id}')">
            ${c.is_vip ? 'مغلق (VIP)' : 'ابدأ التحقيق'}
          </button>
        </div>
      `;
      if (c.is_vip) {
        const lock = document.createElement('div');
        lock.className = 'case-lock-overlay';
        lock.innerHTML = `
          <div class="case-lock">
            <div class="case-lock-icon">🔒</div>
            <div>محتوى VIP</div>
            <div style="font-size:0.75rem;margin-top:0.25rem;opacity:0.9">مطلوب كود تفعيل</div>
          </div>
        `;
        card.appendChild(lock);
        card.classList.add('locked');
      }
      grid.appendChild(card);
    });
  }

  function updateHeroStats() {
    const casesEl = document.querySelector('[data-stat="cases"]');
    const completedEl = document.querySelector('[data-stat="completed"]');
    if (casesEl) casesEl.textContent = cases.length;
    if (completedEl) {
      const comp = Object.values(progress || {}).filter(p => p.case_completed).length;
      completedEl.textContent = comp;
    }
  }

  // ---------- Open a case ----------
  async function openCase(caseId) {
    const user = PD9Auth.getUser();
    if (!user) {
      PD9UI.showToast('يجب تسجيل الدخول لبدء التحقيق', 'error');
      PD9UI.openAuthModal();
      return;
    }

    let c = cases.find(x => x.id === caseId);
    if (!c) {
      try {
        const data = await PD9API.getCase(caseId);
        c = data && data.case ? data.case : null;
      } catch (e) { c = null; }
    }
    if (!c) {
      PD9UI.showToast('القضية غير موجودة', 'error');
      return;
    }

    if (c.is_vip && user.vip_level === 'free') {
      PD9UI.showToast('هذه قضية VIP. يرجى تفعيل كود VIP.', 'error');
      return;
    }

    currentCase = c;

    // Attach stages
    try {
      const data = await PD9API.getCase(caseId);
      if (data && data.case && data.case.stages) currentCase.stages = data.case.stages;
    } catch (e) {}

    caseTitleEl.textContent = c.title_ar;
    caseDescEl.textContent = c.description_ar;

    // Load progress
    try {
      progress = await PD9API.getProgress();
    } catch (e) { progress = {}; }

    const caseProgress = progress[caseId] || {
      current_stage: 1, completed_stages: [], collected_evidence: [], total_xp: 0
    };
    collectedEvidence = caseProgress.collected_evidence || [];

    // Render sidebar notebook
    renderSidebar();

    // Start first stage
    const firstStage = Math.max(1, Math.min(
      caseProgress.current_stage || 1,
      currentCase.stages.length || 1,
    ));
    await loadStage(firstStage, caseId);

    caseEl.classList.remove('hidden');
    PD9Audio.play('unlock');
  }

  // ---------- Load a stage ----------
  async function loadStage(stageNumber, caseId) {
    mainEl.innerHTML = '<div style="text-align:center;color:var(--text-muted);padding:2rem;">جاري تحميل المرحلة...</div>';

    const stageList = currentCase && currentCase.stages ? currentCase.stages : [];
    const summary = stageList.find(st => st.stage_number === stageNumber);
    if (!summary) {
      mainEl.innerHTML = '<div class="empty-state">لا توجد مرحلة تالية في هذه القضية.</div>';
      return;
    }

    let stage;
    try {
      const result = await PD9API.getStage(summary.id);
      stage = result && result.stage;
    } catch (e) {
      console.error('[PD9Cases] stage detail unavailable', e);
      mainEl.innerHTML = '<div class="empty-state">تعذر تحميل المرحلة. حاول مرة أخرى.</div>';
      PD9UI.showToast('تعذر تحميل بيانات المرحلة', 'error');
      return;
    }

    if (!stage || !stage.content_ar) {
      mainEl.innerHTML = '<div class="empty-state">بيانات المرحلة غير مكتملة.</div>';
      PD9UI.showToast('بيانات المرحلة غير مكتملة', 'error');
      return;
    }

    currentStage = stage;
    hintIndex = 0;
    window.PD9Cases_selectedVerdict = null;
    renderStage(stage);
    updateProgressBar(caseId);
    PD9Audio.play('transition');
  }

  function getDemoStage(num, caseId) {
    return {
      id: `demo-stage-${caseId}-${num}`,
      stage_number: num,
      title_ar: `المرحلة ${num}: التحليل`,
      puzzle_type: 'image_analysis',
      content_ar: {
        instruction: 'ابحث عن الدليل المخفي في صورة مسرح الجريمة.',
      },
      hints: ['ركز على التفاصيل الدقيقة', 'انتبه للأشياء غير العادية'],
      xp_reward: 25,
      correct_answer: { answer: 'دليل' },
    };
  }

  // ---------- Render sidebar notebook ----------
  function renderSidebar() {
    if (!sidebarEl) return;
    let html = `
      <div class="cp-section">
        <h4>دفتر الملاحظات</h4>
        <div class="notebook-item">
          <div class="item-title">${currentCase ? currentCase.title_ar : 'القضية الحالية'}</div>
          <div class="item-text">المرحلة: ${currentStage ? currentStage.stage_number : 1} | الأدلة: ${collectedEvidence.length}</div>
        </div>
      </div>
    `;

    // Evidence bag
    html += `<div class="cp-section"><h4>حقيبة الأدلة</h4>`;
    if (!collectedEvidence.length) {
      html += '<div class="notebook-item"><div class="item-text">حقيبة الأدلة فارغة.</div></div>';
    } else {
      collectedEvidence.forEach((ev, i) => {
        html += `
          <div class="notebook-item evidence-item" onclick="PD9Cases.selectEvidence(${i})">
            <div class="item-title">${ev.name || 'أدلة'}</div>
            <div class="item-text">${ev.note || ''}</div>
          </div>
        `;
      });
    }
    html += '</div>';

    // XP
    const user = PD9Auth.getUser();
    const xp = user ? user.xp : 0;
    const level = user ? user.level : 1;
    html += `
      <div class="cp-section">
        <h4>تقييم المحقق</h4>
        <div style="margin-bottom:0.5rem;">المستوى ${level}</div>
        <div class="xp-bar"><div class="xp-fill" style="width:${Math.min(100, xp % 100)}%"></div></div>
        <div style="text-align:right;font-size:0.8rem;color:var(--text-muted);margin-top:0.25rem;">${xp} XP</div>
      </div>
    `;

    sidebarEl.innerHTML = html;
  }

  function selectEvidence(index) {
    const ev = collectedEvidence[index];
    if (!ev) return;
    PD9UI.showToast(`الأدلة: ${ev.name || 'عنصر'}\n${ev.note || ''}`, 'info');
  }

  // ---------- Render a stage ----------
  function renderStage(stage) {
    const pt = stage.puzzle_type || 'image_analysis';
    const content = stage.content_ar || {};
    let html = `
      <div class="stage-content">
        <div class="stage-header">
          <h2>${stage.title_ar}</h2>
          <div class="stage-instructions">${content.instruction || 'استنتج الحل وقدم إجابتك.'}</div>
        </div>
    `;

    // ---- Intro ----
    if (pt === 'intro') {
      html += `
        <div class="intro-stage" style="text-align:center;max-width:600px;margin:0 auto;">
          <div class="story-box" style="background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);padding:2rem;margin-bottom:2rem;line-height:1.8;color:var(--text-muted);font-size:1.05rem;">
            ${content.story || 'لا توجد قصة متاحة لهذه المرحلة.'}
          </div>
          <input type="text" id="stage-answer" placeholder="اكتب 'بدء' للمتابعة">
        </div>
      `;
    }

    // ---- Image analysis ----
    else if (pt === 'image_analysis') {
      html += `
        <div class="image-analysis">
          <div class="image-frame">
            <img src="assets/images/crime-scene.svg" alt="مسرح الجريمة" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
            <div style="display:none;align-items:center;justify-content:center;height:300px;color:var(--text-muted);">صورة مسرح الجريمة غير متوفرة</div>
            <div class="zoom-hint">انقر للبحث عن التفاصيل المخفية</div>
          </div>
          <p class="instruction">${content.instruction || 'ابحث عن الدليل المخفي في الصورة.'}</p>
          <div class="analysis-result" id="analysis-result"></div>
          <input type="text" id="stage-answer" placeholder="أكتب الدليل الذي وجدته">
        </div>
      `;
    }

    // ---- Fingerprint ----
    else if (pt === 'fingerprint') {
      html += `
        <div class="fingerprint-stage">
          <div class="fingerprint-card">
            <div class="fp-placeholder">👆</div>
          </div>
          <div class="fingerprint-comparison">
            <div class="fp-sample"><div class="fp-placeholder">👤</div><div>بصمة المشتبه به أ</div></div>
            <div class="fp-sample"><div class="fp-placeholder">👤</div><div>بصمة مسرح الجريمة</div></div>
          </div>
          <p class="instruction" style="text-align:center;max-width:500px;margin:1rem auto 0;">هل البصمتان متطابقتان؟</p>
          <input type="text" id="stage-answer" placeholder="نعم / لا">
        </div>
      `;
    }

    // ---- CCTV ----
    else if (pt === 'cctv') {
      const segments = (content.segments || []).map(seg => `
        <div class="cctv-segment" data-id="${seg.id}" onclick="PD9Cases.selectCCTV('${seg.id}')">${seg.label}</div>
      `).join('');
      html += `
        <div class="cctv-stage">
          <div class="cctv-frame">
            <div class="cctv-overlay">REC • CAM-01 • ${new Date().toLocaleString('ar-SA')}</div>
          </div>
          <div class="cctv-timeline">${segments}</div>
          <p class="instruction" style="text-align:center;margin-top:1rem;">اختر المقطع الذي يظهر فيه المشتبه به.</p>
          <input type="text" id="stage-answer" placeholder="رقم المقطع المختار">
        </div>
      `;
    }

    // ---- Cipher ----
    else if (pt === 'cipher') {
      html += `
        <div class="cipher-stage">
          <div class="cipher-text" id="cipher-text">${content.cipher || 'مرفق مشفر...'}</div>
          <div class="cipher-input-group">
            <input type="text" id="stage-answer" placeholder="أكتب النص المفكوك">
          </div>
        </div>
      `;
    }

    // ---- Timeline ----
    else if (pt === 'timeline') {
      const events = (content.events || [
        { id: 'e1', text: 'وصول الضحية إلى المكان' },
        { id: 'e2', text: 'سماع صوت خطأ' },
        { id: 'e3', text: 'اكتشاف الجثة' },
      ]).map(ev => `
        <div class="timeline-item" data-id="${ev.id}" draggable="true">${ev.text}</div>
      `).join('');
      html += `
        <div class="timeline-stage">
          <div class="timeline-instructions">رتب الأحداث وفق التسلسل الزمني الصحيح (اسحب العناصر):</div>
          <div class="timeline-container" id="timeline-container">${events}</div>
          <input type="text" id="stage-answer" placeholder="أكتب ترتيب الأحداث بالأرقام (مثال: 1,3,2)">
        </div>
      `;
    }

    // ---- Contradiction ----
    else if (pt === 'contradiction') {
      const stmts = (content.statements || [
        { speaker: 'الشاهد أ', text: 'إفادة أولية' },
        { speaker: 'الشاهد ب', text: 'إفادة ثانية' },
      ]).map(s => `
        <div class="statement-card" onclick="PD9Cases.selectStatement(this)">
          <div class="statement-speaker">${s.speaker}</div>
          <div class="statement-text">${s.text}</div>
        </div>
      `).join('');
      html += `
        <div class="statements-stage">
          <div class="statement-instructions" style="text-align:center;margin-bottom:1rem;">اختر الإفادة التي تتناقض مع الأخرى:</div>
          ${stmts}
          <input type="text" id="stage-answer" placeholder="اسم الشاهد الكاذب">
        </div>
      `;
    }

    // ---- Evidence link ----
    else if (pt === 'evidence_link') {
      const items = (content.evidence || [
        { id: 'ev1', name: 'مفتاح الاستوديو', icon: '🔑' },
        { id: 'ev2', name: 'بصمة الإصبع', icon: '👆' },
        { id: 'ev3', name: 'تسجيل صوتي', icon: '🎵' },
      ]).map(ev => `
        <div class="evidence-item" onclick="PD9Cases.toggleEvidenceLink('${ev.id}')" data-id="${ev.id}">
          <div class="evidence-icon">${ev.icon}</div>
          <div class="evidence-name">${ev.name}</div>
        </div>
      `).join('');
      html += `
        <div class="evidence-link-stage">
          <p class="instruction" style="text-align:center;margin-bottom:1.5rem;">اختر الأدلة التي تربط بينها للوصول إلى الاستنتاج:</div>
          <div class="evidence-grid">${items}</div>
          <input type="text" id="stage-answer" placeholder="أكتب أسماء الأدلة المرتبطة">
        </div>
      `;
    }

    // ---- Interrogation ----
    else if (pt === 'interrogation') {
      const suspects = (content.suspects || [
        { id: 's1', name: 'المشتبه به أ', role: 'مشتبه به' },
        { id: 's2', name: 'المشتبه به ب', role: 'مشتبه به' },
      ]);
      const questions = (content.questions || [
        { id: 'q1', text: 'أين كنت وقت الجريمة؟', correct: false },
        { id: 'q2', text: 'لماذا كانت بصمتك على الدليل؟', correct: true },
      ]);
      const qHtml = questions.map(q => `
        <button class="question-btn" data-id="${q.id}" data-correct="${q.correct}" onclick="PD9Cases.askQuestion(this)">
          ${q.text}
        </button>
      `).join('');
      html += `
        <div class="interrogation-stage">
          <div class="suspect-profile">
            <div class="suspect-avatar">👤</div>
            <div class="suspect-info">
              <h3>${suspects[0]?.name || 'المشتبه به الرئيسي'}</h3>
              <p>${suspects[0]?.role || 'الدوافع غير واضحة'}</p>
            </div>
          </div>
          <div class="question-list" id="question-list">${qHtml}</div>
          <input type="text" id="stage-answer" placeholder="أكتب استنتاجك من الاستجواب">
        </div>
      `;
    }

    // ---- Forensic report ----
    else if (pt === 'forensic_report') {
      html += `
        <div class="forensic-stage">
          <div class="report-box" style="background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);padding:1.5rem;margin-bottom:1.5rem;line-height:1.7;">
            ${content.report || 'تقرير الطب الشرعي غير متوفر.'}
          </div>
          <input type="text" id="stage-answer" placeholder="أكتب استنتاجك من التقرير">
        </div>
      `;
    }

    // ---- Verdict ----
    else if (pt === 'verdict') {
      const suspects = (content.suspects || [
        { id: 'sus1', name_ar: 'المشتبه به 1' },
        { id: 'sus2', name_ar: 'المشتبه به 2' },
        { id: 'sus3', name_ar: 'المشتبه به 3' },
      ]);
      const susHtml = suspects.map(s => `
        <div class="verdict-suspect" data-id="${s.id}" onclick="PD9Cases.selectVerdictSuspect('${s.id}')">
          <div class="avatar">👤</div>
          <div class="name">${s.name_ar}</div>
        </div>
      `).join('');
      html += `
        <div class="verdict-stage">
          <p style="color:var(--text-muted);margin-bottom:2rem;">اختر الجاني بناءً على الأدلة التي جمعتها:</p>
          <div class="verdict-suspects" id="verdict-suspects">${susHtml}</div>
          <div class="verdict-actions">
            <button class="btn btn-primary" id="verdict-submit" onclick="PD9Cases.submitVerdict()">إصدار الحكم</button>
          </div>
          <div class="verdict-result" id="verdict-result"></div>
        </div>
      `;
    }

    html += `</div>`;
    mainEl.innerHTML = html;

    submitBtn.onclick = () => submitAnswer();
    hintBtn.onclick = () => showHint();
    submitBtn.style.display = pt === 'verdict' ? 'none' : '';
  }

  // ---------- CCTV selection ----------
  window.PD9Cases_selectCCTV = (id) => {
    document.querySelectorAll('.cctv-segment').forEach(el => {
      el.classList.toggle('selected', el.dataset.id === id);
      if (el.dataset.id === id) el.classList.add('hint');
    });
  };

  // ---------- Statement selection ----------
  window.PD9Cases_selectStatement = (el) => {
    document.querySelectorAll('.statement-card').forEach(c => c.classList.remove('selected'));
    el.classList.add('selected');
  };

  // ---------- Evidence link toggle ----------
  window.PD9Cases_toggleEvidenceLink = (id) => {
    const el = document.querySelector(`.evidence-item[data-id="${id}"]`);
    el.classList.toggle('selected');
  };

  // ---------- Interrogation question ----------
  window.PD9Cases_askQuestion = (btn) => {
    document.querySelectorAll('.question-btn').forEach(b => b.classList.add('used'));
    const correct = btn.dataset.correct === 'true';
    btn.classList.add(correct ? 'correct' : 'wrong');
    PD9Audio.play(correct ? 'success' : 'error');
    PD9UI.showToast(correct ? 'سؤال جيد! حصلت على معلومات مهمة.' : 'هذا السؤال لم يفد.', correct ? 'success' : 'error');
  };

  // ---------- Verdict suspect select ----------
  window.PD9Cases_selectVerdictSuspect = (id) => {
    document.querySelectorAll('.verdict-suspect').forEach(s => s.classList.remove('selected'));
    const el = document.querySelector(`.verdict-suspect[data-id="${id}"]`);
    if (el) el.classList.add('selected');
    window.PD9Cases_selectedVerdict = id;
  };

  // ---------- Submit verdict ----------
  window.PD9Cases_submitVerdict = async () => {
    const selected = window.PD9Cases_selectedVerdict;
    if (!selected) { PD9UI.showToast('يرجى اختيار مشتبه به أولًا', 'error'); return; }
    const resultEl = document.getElementById('verdict-result');
    try {
      const response = await PD9API.submitStageAnswer(currentStage.id, selected);
      resultEl.className = 'verdict-result show ' + (response.correct ? 'success' : 'fail');
      resultEl.textContent = response.correct
        ? 'صحيح! تم إدانة الجاني.'
        : 'إجابة غير صحيحة. راجع الأدلة وحاول مرة أخرى.';
      PD9Audio.play(response.correct ? 'success' : 'error');
      if (response.correct) {
        await saveProgress(currentStage.stage_number + 1);
        if (response.case_completed) {
          await finalizeCase(true);
        } else {
          await loadStage(currentStage.stage_number + 1, currentCase.id);
        }
      }
    } catch (e) {
      PD9UI.showToast(e.message || 'تعذر إرسال الحكم', 'error');
    }
  };

  // ---------- Show hint ----------
  function showHint() {
    if (!currentStage || !currentStage.hints) return;
    if (hintIndex < currentStage.hints.length) {
      PD9Audio.play('hint');
      PD9UI.showToast(`تلميح ${hintIndex + 1}: ${currentStage.hints[hintIndex]}`, 'info');
      hintIndex++;
    } else {
      PD9UI.showToast('لا توجد تلميحات إضافية', 'info');
    }
  }

  // ---------- Collect evidence ----------
  function collectEvidence(name, note) {
    collectedEvidence.push({ name, note, collected_at: new Date().toISOString() });
    renderSidebar();
    PD9Audio.play('evidence');
    PD9UI.showToast('تم إضافة الأدلة إلى حقيبتك', 'success');
  }

  // ---------- Submit answer ----------
  async function submitAnswer() {
    const input = document.getElementById('stage-answer');
    const answer = input ? input.value.trim() : '';
    if (!answer) { PD9UI.showToast('يرجى إدخال إجابة', 'error'); return; }

    // Auto-collect evidence for image analysis if answer matches
    if (currentStage.puzzle_type === 'image_analysis' && answer.includes('مفتاح')) {
      collectEvidence('مفتاح الاستوديو', 'مفتاح وُجد على الطاولة بالقرب من الكوب.');
    }

    try {
      const res = await PD9API.submitStageAnswer(currentStage.id, answer);
      currentAnswer = res;
      if (res.correct) {
        PD9Audio.play('success');
        PD9UI.showToast(res.message || 'إجابة صحيحة!', 'success');
        await saveProgress(currentStage.stage_number + 1);
        if (res.case_completed) {
          await finalizeCase(true);
        } else {
          const next = currentStage.stage_number + 1;
          await loadStage(next, currentCase.id);
        }
      } else {
        PD9Audio.play('error');
        PD9UI.showToast(res.message || 'إجابة خاطئة، حاول مجدداً', 'error');
      }
    } catch (e) {
      PD9UI.showToast(e.message || 'فشل إرسال الإجابة', 'error');
    }
  }

  async function saveProgress(nextStage) {
    const caseId = currentCase.id;
    let prog = progress[caseId] || { current_stage: 1, completed_stages: [], collected_evidence: [], total_xp: 0 };
    prog.current_stage = nextStage;
    if (!prog.completed_stages.includes(currentStage.id)) {
      prog.completed_stages.push(currentStage.id);
      prog.total_xp = (prog.total_xp || 0) + (currentStage.xp_reward || 0);
    }
    prog.collected_evidence = collectedEvidence;
    try {
      await PD9API.saveProgress(caseId, {
        current_stage: prog.current_stage,
        completed_stages: prog.completed_stages,
        collected_evidence: prog.collected_evidence,
        total_xp: prog.total_xp,
      });
    } catch (e) { console.error('save progress failed', e); }
    progress[caseId] = prog;
    updateProgressBar(caseId);
    renderSidebar();
  }

  function updateProgressBar(caseId) {
    const cp = progress[caseId];
    const total = currentCase.stages ? currentCase.stages.length : 5;
    const done = (cp && cp.completed_stages ? cp.completed_stages.length : 0);
    const pct = total ? Math.round((done / total) * 100) : 0;
    if (progressFill) progressFill.style.width = `${pct}%`;
    if (progressPct) progressPct.textContent = `${pct}%`;
  }

  async function finalizeCase(success) {
    const caseId = currentCase.id;
    let prog = progress[caseId] || {};
    prog.case_completed = success;
    prog.case_result = success ? 'solved' : 'failed';
    try {
      await PD9API.saveProgress(caseId, {
        case_completed: success,
        case_result: prog.case_result,
        collected_evidence: collectedEvidence,
      });
    } catch (e) {}
    updateHeroStats();
    PD9UI.showToast(success ? 'تم حل القضية بنجاح! حصلت على شارة وإنجاز.' : 'لم يتم حل القضية. يمكنك المحاولة مجدداً.', success ? 'success' : 'error');
  }

  function closeCase() {
    caseEl.classList.add('hidden');
    currentCase = null;
    currentStage = null;
    collectedEvidence = [];
    PD9Audio.play('click');
  }

  return {
    loadCases,
    renderCasesGrid,
    openCase,
    loadStage,
    submitAnswer,
    closeCase,
    updateHeroStats,
    collectEvidence,
    renderSidebar,
    selectEvidence,
    selectCCTV: window.PD9Cases_selectCCTV,
    selectStatement: window.PD9Cases_selectStatement,
    toggleEvidenceLink: window.PD9Cases_toggleEvidenceLink,
    askQuestion: window.PD9Cases_askQuestion,
    selectVerdictSuspect: window.PD9Cases_selectVerdictSuspect,
    submitVerdict: window.PD9Cases_submitVerdict,
  };
})();

window.PD9Cases = PD9Cases;
