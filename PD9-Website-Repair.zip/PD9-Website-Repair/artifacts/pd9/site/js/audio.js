/* ============================================
   PD9 - Audio System
   Respects browser autoplay policy: sound starts after user interaction.
   Uses local audio files (place them in assets/audio/).
   ============================================ */

const PD9Audio = (() => {
  let ctx = null;
  let enabled = false;
  let volume = 0.5;
  const sounds = {};

  const AUDIO_MAP = {
    bg: 'assets/audio/background.mp3',
    click: 'assets/audio/click.mp3',
    unlock: 'assets/audio/unlock.mp3',
    evidence: 'assets/audio/evidence.mp3',
    success: 'assets/audio/success.mp3',
    error: 'assets/audio/error.mp3',
    hint: 'assets/audio/hint.mp3',
    transition: 'assets/audio/transition.mp3',
    ambient: 'assets/audio/ambient.mp3',
  };

  async function init() {
    if (typeof window === 'undefined') return;
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return;
    ctx = new AudioContext();
    volume = parseFloat(localStorage.getItem(PD9_CONFIG.storage.volume)) || 0.5;
    const saved = localStorage.getItem(PD9_CONFIG.storage.soundEnabled);
    enabled = saved === null ? true : saved === 'true';
  }

  async function loadBuffer(url) {
    if (!ctx) return null;
    try {
      const res = await fetch(url);
      if (!res.ok) return null;
      const buf = await res.arrayBuffer();
      return await ctx.decodeAudioData(buf);
    } catch (e) {
      console.warn('[PD9Audio] Failed to load', url, e);
      return null;
    }
  }

  async function preload() {
    if (!ctx) return;
    for (const [key, url] of Object.entries(AUDIO_MAP)) {
      sounds[key] = await loadBuffer(url);
    }
  }

  function play(key, opts = {}) {
    if (!enabled || !ctx || !sounds[key]) return;
    try {
      const src = ctx.createBufferSource();
      src.buffer = sounds[key];
      const gain = ctx.createGain();
      gain.gain.value = volume * (opts.volume || 1);
      src.connect(gain);
      gain.connect(ctx.destination);
      src.start(0);
    } catch (e) {
      console.warn('[PD9Audio] play error', key, e);
    }
  }

  async function startBg() {
    if (!enabled || !ctx) return;
    if (ctx.state === 'suspended') await ctx.resume();
    play('ambient', { volume: 0.3 });
  }

  function toggle() {
    enabled = !enabled;
    localStorage.setItem(PD9_CONFIG.storage.soundEnabled, String(enabled));
    if (enabled && ctx) startBg();
    return enabled;
  }

  function setVol(v) {
    volume = Math.max(0, Math.min(1, v));
    localStorage.setItem(PD9_CONFIG.storage.volume, String(volume));
  }

  return { init, preload, play, toggle, setVol, startBg, enabled: () => enabled };
})();

window.PD9Audio = PD9Audio;
