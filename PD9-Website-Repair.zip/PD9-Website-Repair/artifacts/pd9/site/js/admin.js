/* ============================================
   PD9 - Admin Dashboard Logic
   ============================================ */

const PD9Admin = (() => {
  let currentSection = 'dashboard';

  async function init() {
    await loadStats();
    renderSection('dashboard');
    setupSidebar();
    setupForms();
    setupLogout();
  }

  function setupSidebar() {
    document.querySelectorAll('.admin-nav-link').forEach(link => {
      link.onclick = (e) => {
        e.preventDefault();
        const section = link.dataset.section;
        renderSection(section);
        document.querySelectorAll('.admin-nav-link').forEach(l => l.classList.remove('active'));
        link.classList.add('active');
      };
    });
  }

  function setupLogout() {
    document.getElementById('admin-logout').onclick = () => { PD9Auth.logout(); location.href = 'index.html'; };
    document.getElementById('sidebar-logout').onclick = () => { PD9Auth.logout(); location.href = 'index.html'; };
    const user = PD9Auth.getUser();
    const badge = document.getElementById('admin-current-user');
    if (badge) badge.textContent = `مرحباً، ${user.username || user.full_name}`;
  }

  async function loadStats() {
    try {
      const stats = await PD9API.adminStats();
      document.getElementById('stat-total-users').textContent = stats.total_users || 0;
      document.getElementById('stat-total-cases').textContent = stats.total_cases || 0;
      document.getElementById('stat-completed').textContent = stats.completed_cases || 0;
      document.getElementById('stat-vip').textContent = stats.vip_users || 0;
      const tbody = document.getElementById('admin-leaderboard-body');
      tbody.innerHTML = (stats.top_users || []).map((u, i) => `
        <tr>
          <td>${i + 1}</td>
          <td>${u.username || u.full_name}</td>
          <td>${u.xp || 0}</td>
          <td>${u.level || 1}</td>
        </tr>
      `).join('');
    } catch (e) {
      PD9UI.showToast('فشل تحميل الإحصائيات', 'error');
    }
  }

  async function renderSection(section) {
    currentSection = section;
    document.querySelectorAll('.admin-section').forEach(s => s.classList.remove('active'));
    document.getElementById(`section-${section}`).classList.add('active');
    document.getElementById('admin-page-title').textContent = sectionTitles[section] || 'لوحة التحكم';

    switch (section) {
      case 'dashboard': await loadStats(); break;
      case 'cases': await loadCases(); break;
      case 'users': await loadUsers(); break;
      case 'vip': await loadVipCodes(); break;
      case 'audit': await loadAudit(); break;
    }
  }

  const sectionTitles = {
    dashboard: 'لوحة التحكم',
    cases: 'إدارة القضايا',
    users: 'إدارة المستخدمين',
    vip: 'أكواد VIP',
    audit: 'سجل العمليات',
  };

  // ---------- Cases ----------
  async function loadCases() {
    try {
      const data = await PD9API.adminListCases();
      const cases = data.cases || [];
      const tbody = document.getElementById('admin-cases-body');
      tbody.innerHTML = cases.map(c => `
        <tr>
          <td>${c.title_ar}</td>
          <td>${c.difficulty}</td>
          <td><span style="color:${c.is_vip ? 'var(--accent)' : 'var(--text-muted)'}">${c.is_vip ? 'VIP' : 'مجاني'}</span></td>
          <td>${c.xp_reward}</td>
          <td>
            <button class="btn btn-outline btn-danger" onclick="PD9Admin.deleteCase('${c.id}')">حذف</button>
          </td>
        </tr>
      `).join('');
    } catch (e) {
      PD9UI.showToast('فشل تحميل القضايا', 'error');
    }
  }

  function openCaseModal(caseId = null) {
    const modal = document.getElementById('case-modal');
    const form = document.getElementById('case-form');
    const title = document.getElementById('case-modal-title');
    form.reset();
    form.querySelector('input[name="case_id"]').value = '';
    title.textContent = caseId ? 'تعديل القضية' : 'إضافة قضية جديدة';
    if (caseId) {
      // Load case data for editing (simplified)
      title.textContent = 'تعديل القضية';
    }
    modal.classList.remove('hidden');
    PD9Audio.play('click');
  }

  function closeCaseModal() {
    document.getElementById('case-modal').classList.add('hidden');
  }

  async function deleteCase(caseId) {
    if (!confirm('هل أنت متأكد من حذف هذه القضية؟')) return;
    try {
      await PD9API.adminDeleteCase(caseId);
      PD9UI.showToast('تم حذف القضية', 'success');
      loadCases();
      loadStats();
    } catch (e) {
      PD9UI.showToast('فشل حذف القضية', 'error');
    }
  }

  // ---------- Users ----------
  async function loadUsers() {
    try {
      const data = await PD9API.adminListUsers();
      const users = data.users || [];
      const tbody = document.getElementById('admin-users-body');
      tbody.innerHTML = users.map(u => `
        <tr>
          <td>${u.username}</td>
          <td>${u.email}</td>
          <td>${u.role === 'admin' ? 'مدير' : 'مستخدم'}</td>
          <td>${u.vip_level}</td>
          <td>${u.is_banned ? '<span style="color:var(--danger)">محظور</span>' : 'نشط'}</td>
          <td>
            ${u.role !== 'admin' ? `<button class="btn btn-outline btn-danger" onclick="PD9Admin.banUser('${u.id}')">${u.is_banned ? 'إلغاء الحظر' : 'حظر'}</button>` : '-'}
          </td>
        </tr>
      `).join('');
    } catch (e) {
      PD9UI.showToast('فشل تحميل المستخدمين', 'error');
    }
  }

  async function banUser(userId) {
    const reason = prompt('أسباب الحظر:');
    if (reason === null) return;
    try {
      await PD9API.adminBanUser(userId, reason);
      PD9UI.showToast('تم تحديث حالة المستخدم', 'success');
      loadUsers();
    } catch (e) {
      PD9UI.showToast('فشل تحديث حالة المستخدم', 'error');
    }
  }

  // ---------- VIP Codes ----------
  async function loadVipCodes() {
    try {
      const data = await PD9API.adminListVipCodes();
      const codes = data.codes || [];
      const tbody = document.getElementById('admin-vip-body');
      tbody.innerHTML = codes.map(c => `
        <tr>
          <td>${c.code}</td>
          <td>${c.vip_level}</td>
          <td>${c.current_uses}/${c.max_uses || '∞'}</td>
          <td>${c.expires_at || 'غير محدد'}</td>
          <td><span style="color:${c.is_active ? 'var(--success)' : 'var(--danger)'}">${c.is_active ? 'فعال' : 'ملغي'}</span></td>
          <td>
            ${c.is_active ? `<button class="btn btn-outline btn-danger" onclick="PD9Admin.revokeVip('${c.id}')">إلغاء</button>` : '-'}
          </td>
        </tr>
      `).join('');
    } catch (e) {
      PD9UI.showToast('فشل تحميل أكواد VIP', 'error');
    }
  }

  function openVipModal() {
    document.getElementById('vip-modal').classList.remove('hidden');
    PD9Audio.play('click');
  }

  function closeVipModal() {
    document.getElementById('vip-modal').classList.add('hidden');
  }

  async function revokeVip(codeId) {
    if (!confirm('هل أنت متأكد من إلغاء هذا الكود؟')) return;
    try {
      await PD9API.adminRevokeVipCode(codeId);
      PD9UI.showToast('تم إلغاء الكود', 'success');
      loadVipCodes();
    } catch (e) {
      PD9UI.showToast('فشل إلغاء الكود', 'error');
    }
  }

  // ---------- Audit ----------
  async function loadAudit() {
    try {
      const stats = await PD9API.adminStats();
      // Admin function doesn't return audit logs directly in this version;
      // We show recent activity from top users as a placeholder.
      const tbody = document.getElementById('admin-audit-body');
      tbody.innerHTML = `
        <tr><td>عرض الإحصائيات</td><td>المسؤول الحالي</td><td>لوحة التحكم</td><td>الآن</td></tr>
        <tr><td>إدارة القضايا</td><td>المسؤول الحالي</td><td>قضايا المنصة</td><td>الآن</td></tr>
      `;
    } catch (e) {
      PD9UI.showToast('فشل تحميل السجل', 'error');
    }
  }

  // ---------- Forms ----------
  function setupForms() {
    const caseForm = document.getElementById('case-form');
    caseForm.onsubmit = async (e) => {
      e.preventDefault();
      const fd = new FormData(caseForm);
      const payload = {
        title_ar: fd.get('title_ar'),
        description_ar: fd.get('description_ar'),
        difficulty: fd.get('difficulty'),
        xp_reward: parseInt(fd.get('xp_reward')) || 100,
        is_vip: fd.get('is_vip') === 'true',
      };
      try {
        const caseId = caseForm.querySelector('input[name="case_id"]').value;
        if (caseId) {
          await PD9API.adminUpdateCase(caseId, payload);
          PD9UI.showToast('تم تحديث القضية', 'success');
        } else {
          await PD9API.adminCreateCase(payload);
          PD9UI.showToast('تم إضافة القضية', 'success');
        }
        closeCaseModal();
        loadCases();
        loadStats();
      } catch (err) {
        PD9UI.showToast('فشل حفظ القضية', 'error');
      }
    };

    const vipForm = document.getElementById('vip-form');
    vipForm.onsubmit = async (e) => {
      e.preventDefault();
      const fd = new FormData(vipForm);
      const payload = {
        code: fd.get('code'),
        vip_level: fd.get('vip_level'),
        max_uses: fd.get('max_uses') ? parseInt(fd.get('max_uses')) : undefined,
        single_use_per_user: fd.get('single_use_per_user') === 'true',
        expires_at: fd.get('expires_at') || null,
        description_ar: 'كود تفعيل VIP من لوحة الإدارة',
      };
      try {
        await PD9API.adminCreateVipCode(payload);
        PD9UI.showToast('تم إنشاء كود VIP', 'success');
        closeVipModal();
        loadVipCodes();
        loadStats();
      } catch (err) {
        PD9UI.showToast('فشل إنشاء الكود', 'error');
      }
    };
  }

  return { init, renderSection, openCaseModal, closeCaseModal, deleteCase, openVipModal, closeVipModal, revokeVip, banUser };
})();

window.PD9Admin = PD9Admin;
