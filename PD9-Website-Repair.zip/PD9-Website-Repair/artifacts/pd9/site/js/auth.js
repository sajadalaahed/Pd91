/* ============================================
   PD9 - Authentication
   ============================================ */

const PD9Auth = (() => {
  let currentUser = null;
  const listeners = [];

  function subscribe(fn) { listeners.push(fn); }
  function notify() { listeners.forEach(fn => fn(currentUser)); }

  async function login(identifier, password) {
    const data = await PD9API.login(identifier, password);
    if (data.token) {
      localStorage.setItem(PD9_CONFIG.storage.token, data.token);
      currentUser = data.user;
      localStorage.setItem(PD9_CONFIG.storage.user, JSON.stringify(currentUser));
      notify();
      PD9Audio.play('unlock');
    }
    return data;
  }

  async function register(payload) {
    const data = await PD9API.register(payload);
    if (data.token) {
      localStorage.setItem(PD9_CONFIG.storage.token, data.token);
      currentUser = data.user;
      localStorage.setItem(PD9_CONFIG.storage.user, JSON.stringify(currentUser));
      notify();
      PD9Audio.play('unlock');
    }
    return data;
  }

  function logout() {
    PD9API.logout();
    currentUser = null;
    localStorage.removeItem(PD9_CONFIG.storage.token);
    localStorage.removeItem(PD9_CONFIG.storage.user);
    notify();
    PD9Audio.play('click');
  }

  async function init() {
    const stored = localStorage.getItem(PD9_CONFIG.storage.user);
    const token = localStorage.getItem(PD9_CONFIG.storage.token);
    if (stored && token) {
      currentUser = JSON.parse(stored);
      notify();
      // Validate with server
      try {
        await PD9API.me();
      } catch (e) {
        logout();
      }
    }
  }

  function getUser() { return currentUser; }
  function isAuthenticated() { return !!currentUser && !!localStorage.getItem(PD9_CONFIG.storage.token); }
  function isAdmin() { return currentUser && currentUser.role === 'admin'; }

  return { init, login, register, logout, getUser, isAuthenticated, isAdmin, subscribe };
})();

window.PD9Auth = PD9Auth;
