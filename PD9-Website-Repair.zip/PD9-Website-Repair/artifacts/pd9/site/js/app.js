/* ============================================
   PD9 - Main App Initialization
   ============================================ */

document.addEventListener('DOMContentLoaded', async () => {
  // Initialize audio
  await PD9Audio.init();

  // Initialize auth (restore session)
  await PD9Auth.init();

  // Load cases
  await PD9Cases.loadCases();

  // Update navbar user state
  PD9UI.updateNavUser();

  // Wire auth modal
  const userBtn = document.getElementById('user-btn');
  const closeAuth = document.getElementById('auth-modal-close');
  const loginForm = document.getElementById('login-form');
  const registerForm = document.getElementById('register-form');
  const authTabs = document.querySelectorAll('.auth-tab');

  if (userBtn) {
    if (PD9Auth.isAuthenticated()) {
      PD9UI.updateNavUser();
    } else {
      userBtn.onclick = PD9UI.openAuthModal;
    }
  }

  if (closeAuth) closeAuth.onclick = PD9UI.closeAuthModal;

  if (loginForm) loginForm.onsubmit = PD9UI.handleLogin;
  if (registerForm) registerForm.onsubmit = PD9UI.handleRegister;

  authTabs.forEach(tab => {
    tab.onclick = () => PD9UI.switchAuthTab(tab.dataset.tab);
  });

  // Case player close
  const closeCase = document.getElementById('case-player-close');
  if (closeCase) closeCase.onclick = () => PD9Cases.closeCase();

  // Close case player on backdrop click
  const backdrop = document.querySelector('.case-player-backdrop');
  if (backdrop) backdrop.onclick = () => PD9Cases.closeCase();

  // Navbar scroll effect
  const navbar = document.getElementById('navbar');
  window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
      navbar.style.padding = '0.5rem 1.5rem';
      navbar.style.height = '60px';
    } else {
      navbar.style.padding = '0 1.5rem';
      navbar.style.height = '70px';
    }
  });

  console.log('[PD9] Platform initialized. Version', PD9_CONFIG.version);
});

// Expose for inline HTML handlers
window.PD9UI = PD9UI;
window.PD9Auth = PD9Auth;
window.PD9Cases = PD9Cases;
window.PD9Detective = PD9Detective;
