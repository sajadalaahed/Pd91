import path from 'node:path';
import fs from 'node:fs/promises';
import { defineConfig } from 'vite';

const port = Number(process.env.PORT || 5173);
const siteRoot = path.resolve(import.meta.dirname, 'site');
const outDir = path.resolve(import.meta.dirname, 'dist/public');

export default defineConfig({
  base: '/',
  root: siteRoot,
  plugins: [
    {
      name: 'pd9-copy-legacy-static-files',
      async closeBundle() {
        await fs.cp(path.resolve(siteRoot, 'js'), path.resolve(outDir, 'js'), { recursive: true });
        await fs.cp(path.resolve(siteRoot, 'assets'), path.resolve(outDir, 'assets'), { recursive: true });
      },
    },
  ],
  build: {
    outDir,
    emptyOutDir: true,
    rollupOptions: {
      input: {
        home: path.resolve(siteRoot, 'index.html'),
        admin: path.resolve(siteRoot, 'admin.html'),
        profile: path.resolve(siteRoot, 'profile.html'),
        terms: path.resolve(siteRoot, 'terms.html'),
        privacy: path.resolve(siteRoot, 'privacy.html'),
      },
    },
  },
  server: {
    port,
    strictPort: false,
    host: '0.0.0.0',
    allowedHosts: true,
  },
  preview: {
    port,
    host: '0.0.0.0',
    allowedHosts: true,
  },
});
