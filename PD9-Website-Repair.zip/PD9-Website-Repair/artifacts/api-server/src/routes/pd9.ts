import { createRequire } from "node:module";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { Router, type IRouter } from "express";
import type { Request, Response } from "express";

type LegacyHandler = (req: Request, res: Response) => Promise<void> | void;
type LegacyFunction = { handler: LegacyHandler };

const apiRoot = path.resolve(
  path.dirname(fileURLToPath(import.meta.url)),
  "..",
);
const requireFromApi = createRequire(path.join(apiRoot, "package.json"));
const functionsDir = path.join(apiRoot, "src/pd9/functions");

// Keep PD9's existing server-side handlers and data model intact. This adapter
// lets the existing Netlify-style route handlers run behind the shared API.
const handlers: Record<string, LegacyHandler> = {
  auth: (requireFromApi(path.join(functionsDir, "auth.cjs")) as LegacyFunction)
    .handler,
  cases: (requireFromApi(path.join(functionsDir, "cases.cjs")) as LegacyFunction)
    .handler,
  progress: (
    requireFromApi(path.join(functionsDir, "progress.cjs")) as LegacyFunction
  ).handler,
  vip: (requireFromApi(path.join(functionsDir, "vip.cjs")) as LegacyFunction)
    .handler,
  admin: (requireFromApi(path.join(functionsDir, "admin.cjs")) as LegacyFunction)
    .handler,
};

const router: IRouter = Router();

router.use(async (req, res, next): Promise<void> => {
  try {
    const url = new URL(req.url, "http://pd9.local");
    const route =
      url.searchParams.get("r") || url.pathname.replace(/\/$/, "");
    const routePrefix = route.split("/").filter(Boolean)[0];
    const functionName = routePrefix === "stages" ? "cases" : routePrefix;
    const handler = functionName ? handlers[functionName] : undefined;

    if (!handler) {
      res.status(404).json({ message: "نقطة النهاية غير موجودة" });
      return;
    }

    await handler(req, res);
  } catch (error) {
    req.log.error({ err: error }, "PD9 request failed");
    next(error);
  }
});

export default router;
