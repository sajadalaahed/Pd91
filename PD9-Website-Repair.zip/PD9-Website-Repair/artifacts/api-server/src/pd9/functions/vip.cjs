/* ============================================
   PD9 - Netlify Function: vip
   Server-side VIP code verification (never in browser).
   Endpoints:
     POST /vip/redeem
     GET  /vip/tiers
   ============================================ */

const { verifyJwt, store, storeReady } = require('../lib/store.cjs');

function json(res, status, body) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.end(JSON.stringify(body));
}

function getToken(req) {
  const auth = req.headers.authorization || '';
  return auth.startsWith('Bearer ') ? auth.slice(7) : null;
}

async function handler(req, res) {
  await storeReady;
  const url = new URL(req.url, `http://${req.headers.host}`);
  const path = url.searchParams.get('r') || url.pathname.replace(/\/$/, '');
  const method = req.method;

  if (method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    });
    res.end();
    return;
  }

  try {
    // ---------- POST /vip/redeem ----------
    if (path === '/vip/redeem' && method === 'POST') {
      const token = getToken(req);
      if (!token) return json(res, 401, { message: 'تسجيل الدخول مطلوب' });
      const payload = verifyJwt(token);
      if (!payload) return json(res, 401, { message: 'جلسة غير صالحة' });

      let body;
      try { body = JSON.parse(await new Promise(r => { let d=''; req.on('data',c=>d+=c); req.on('end',()=>r(d)); })); } catch { return json(res,400,{message: 'بيانات غير صالحة'}); }

      const code = String(body.code || '').trim().toUpperCase();
      if (!code) return json(res, 400, { message: 'يرجى إدخال كود التفعيل' });

      const vipCode = store.vipCodes.find(c => c.code === code);
      if (!vipCode) return json(res, 404, { message: 'كود التفعيل غير صحيح أو غير موجود' });
      if (!vipCode.is_active) return json(res, 403, { message: 'هذا الكود تم إلغاؤه' });
      if (vipCode.expires_at && new Date(vipCode.expires_at) < new Date()) return json(res, 403, { message: 'انتهت صلاحية هذا الكود' });
      if (vipCode.max_uses !== undefined && vipCode.current_uses >= vipCode.max_uses) return json(res, 403, { message: 'استنفد هذا الكود عدد استخداماته المسموح بها' });

      // Single use per user check
      if (vipCode.single_use_per_user) {
        const already = store.vipUsage.find(u => u.codeId === vipCode.id && u.userId === payload.userId);
        if (already) return json(res, 403, { message: 'لقد استخدمت هذا الكود مسبقاً' });
      }

      // Apply VIP
      const user = store.users.find(u => u.id === payload.userId);
      if (!user) return json(res, 404, { message: 'المستخدم غير موجود' });

      user.vip_level = vipCode.vip_level;
      if (vipCode.expires_at) user.vip_expires_at = vipCode.expires_at;
      else user.vip_expires_at = null;

      // Track usage
      vipCode.current_uses = (vipCode.current_uses || 0) + 1;
      if (vipCode.single_use_per_user) {
        store.vipUsage.push({ codeId: vipCode.id, userId: payload.userId });
      }

      // Audit
      store.auditLogs.push({
        admin_id: payload.userId,
        action: 'redeem_vip_code',
        target_type: 'vip_code',
        target_id: vipCode.id,
        details: { code },
        created_at: new Date().toISOString(),
      });

      return json(res, 200, {
        message: 'تم تفعيل VIP بنجاح!',
        vip_level: user.vip_level,
        vip_expires_at: user.vip_expires_at,
      });
    }

    // ---------- GET /vip/tiers ----------
    if (path === '/vip/tiers' && method === 'GET') {
      const tiers = [
        {
          name: 'مجاني',
          price: 'مجاناً',
          features: ['القضايا المجانية', 'لوحة المحقق الأساسية', 'حفظ التقدم'],
          featured: false,
        },
        {
          name: 'VIP',
          price: 'بم code تفعيل',
          features: ['جميع القضايا بما فيها VIP', 'ألغاز متقدمة', 'شارات حصرية', 'دعم أولويات'],
          featured: true,
        },
      ];
      return json(res, 200, { tiers });
    }

    return json(res, 404, { message: 'نقطة النهاية غير موجودة' });
  } catch (e) {
    console.error('[vip]', e);
    return json(res, 500, { message: 'خطأ في الخادم' });
  }
}

module.exports = { handler };
