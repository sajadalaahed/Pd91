/* ============================================
   PD9 - Netlify Function: cases
   Endpoints:
     GET    /cases
     GET    /cases/:id
     GET    /stages/:id
     POST   /stages/:id/answer
   ============================================ */

const { verifyJwt, store, getCaseProgress, storeReady } = require('../lib/store.cjs');

function json(res, status, body) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.end(JSON.stringify(body));
}

function getToken(req) {
  const auth = req.headers.authorization || '';
  return auth.startsWith('Bearer ') ? auth.slice(7) : null;
}

async function handler(req, res) {
  await storeReady;
  const url = new URL(req.url, `http://${req.headers.host}`);
  const path = url.searchParams.get('r') || url.pathname.replace(/\/$/, '');
  const method = req.method;

  if (method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    });
    res.end();
    return;
  }

  try {
    // ---------- GET /cases ----------
    if (path === '/cases' && method === 'GET') {
      const token = getToken(req);
      let userVip = 'free';
      if (token) {
        const payload = verifyJwt(token);
        if (payload) {
          const u = store.users.find(x => x.id === payload.userId);
          if (u) userVip = u.vip_level;
        }
      }

      const visible = store.cases.map(c => ({
        id: c.id,
        title_ar: c.title_ar,
        title_en: c.title_en,
        description_ar: c.description_ar,
        difficulty: c.difficulty,
        is_vip: c.is_vip,
        xp_reward: c.xp_reward,
        cover_image_url: c.cover_image_url,
        locked: c.is_vip && userVip === 'free',
      }));
      return json(res, 200, { cases: visible });
    }

    // ---------- GET /cases/:id ----------
    const caseMatch = path.match(/^\/cases\/([^/]+)$/);
    if (caseMatch && method === 'GET') {
      const caseId = caseMatch[1];
      const c = store.cases.find(x => x.id === caseId);
      if (!c) return json(res, 404, { message: 'القضية غير موجودة' });

      const stages = store.stages
        .filter(s => s.case_id === caseId)
        .sort((a, b) => a.stage_number - b.stage_number)
        .map(s => ({
          id: s.id,
          stage_number: s.stage_number,
          title_ar: s.title_ar,
          puzzle_type: s.puzzle_type,
          xp_reward: s.xp_reward,
        }));

      return json(res, 200, {
        case: {
          id: c.id,
          title_ar: c.title_ar,
          title_en: c.title_en,
          description_ar: c.description_ar,
          story_ar: c.story_ar,
          difficulty: c.difficulty,
          is_vip: c.is_vip,
          xp_reward: c.xp_reward,
          stages,
        },
      });
    }

    // ---------- GET /stages/:id ----------
    const stageMatch = path.match(/^\/stages\/([^/]+)$/);
    if (stageMatch && method === 'GET') {
      const stageId = stageMatch[1];
      const s = store.stages.find(x => x.id === stageId);
      if (!s) return json(res, 404, { message: 'المرحلة غير موجودة' });
      const parentCase = store.cases.find(x => x.id === s.case_id);
      if (parentCase && parentCase.is_vip) {
        const token = getToken(req);
        const payload = token ? verifyJwt(token) : null;
        const user = payload ? store.users.find(x => x.id === payload.userId) : null;
        if (!user || user.is_banned || user.vip_level === 'free') {
          return json(res, 403, { message: 'هذه المرحلة متاحة لمشتركي VIP فقط' });
        }
      }
      return json(res, 200, {
        stage: {
          id: s.id,
          stage_number: s.stage_number,
          title_ar: s.title_ar,
          puzzle_type: s.puzzle_type,
          content_ar: s.content_ar,
          hints: s.hints || [],
          xp_reward: s.xp_reward,
        },
      });
    }

    // ---------- POST /stages/:id/answer ----------
    const answerMatch = path.match(/^\/stages\/([^/]+)\/answer$/);
    if (answerMatch && method === 'POST') {
      const token = getToken(req);
      if (!token) return json(res, 401, { message: 'تسجيل الدخول مطلوب' });
      const payload = verifyJwt(token);
      if (!payload) return json(res, 401, { message: 'جلسة غير صالحة' });
      const user = store.users.find(x => x.id === payload.userId);
      if (!user || user.is_banned) return json(res, 403, { message: 'الحساب غير متاح' });

      const stageId = answerMatch[1];
      const stage = store.stages.find(x => x.id === stageId);
      if (!stage) return json(res, 404, { message: 'المرحلة غير موجودة' });
      const parentCase = store.cases.find(x => x.id === stage.case_id);
      if (parentCase && parentCase.is_vip && user.vip_level === 'free') {
        return json(res, 403, { message: 'هذه المرحلة متاحة لمشتركي VIP فقط' });
      }

      let body;
      try { body = JSON.parse(await new Promise(r => { let d=''; req.on('data',c=>d+=c); req.on('end',()=>r(d)); })); } catch { return json(res,400,{message: 'بيانات غير صالحة'}); }

      const userAnswer = String(body.answer || '').trim();
      const correct = String(stage.correct_answer.answer || '').trim();

      // Simple comparison (case-insensitive) for demo; admin can set exact answers
      const isCorrect = userAnswer.toLowerCase() === correct.toLowerCase();

      // Update progress
      let prog = getCaseProgress(payload.userId, stage.case_id);
      if (!prog) {
        prog = { userId: payload.userId, caseId: stage.case_id, current_stage: 1, completed_stages: [], collected_evidence: [], total_xp: 0 };
        store.progress.push(prog);
      }

      let resultMsg = '';
      if (isCorrect) {
        if (!prog.completed_stages.includes(stageId)) {
          prog.completed_stages.push(stageId);
          prog.total_xp = (prog.total_xp || 0) + (stage.xp_reward || 0);
        }
        prog.current_stage = Math.max(prog.current_stage, stage.stage_number + 1);

        // Award XP to user
        user.xp = (user.xp || 0) + (stage.xp_reward || 0);
        user.level = Math.floor(user.xp / 100) + 1;

        // Check case completion
        const caseStages = store.stages.filter(s => s.case_id === stage.case_id);
        const allDone = caseStages.every(s => prog.completed_stages.includes(s.id));
        if (allDone) {
          prog.case_completed = true;
          const c = store.cases.find(x => x.id === stage.case_id);
          if (c) {
            user.xp = (user.xp || 0) + (c.xp_reward || 0);
            user.level = Math.floor(user.xp / 100) + 1;
          }
          resultMsg = 'تم إكمال المرحلة والقضية بنجاح!';
        } else {
          resultMsg = 'إجابة صحيحة! الانتقال للمرحلة التالية.';
        }
      } else {
        resultMsg = 'إجابة خاطئة. راجع الأدلة وحاول مجدداً.';
      }

      return json(res, 200, {
        correct: isCorrect,
        message: resultMsg,
        xp_gained: isCorrect ? (stage.xp_reward || 0) : 0,
        case_completed: prog.case_completed,
      });
    }

    return json(res, 404, { message: 'نقطة النهاية غير موجودة' });
  } catch (e) {
    console.error('[cases]', e);
    return json(res, 500, { message: 'خطأ في الخادم' });
  }
}

module.exports = { handler };
