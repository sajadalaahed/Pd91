/* ============================================
   PD9 - Netlify Function: auth
   Endpoints (server-side, no secrets exposed):
     POST /auth/login
     POST /auth/register
     POST /auth/logout
     GET  /auth/me
   ============================================ */

const crypto = require('crypto');
const { verifyJwt, signJwt, hashPassword, findUserByEmailOrUsername, findUserById, verifyPassword, publicUser, store, storeReady } = require('../lib/store.cjs');

function json(res, status, body) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.end(JSON.stringify(body));
}

function getBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', chunk => data += chunk);
    req.on('end', () => {
      try { resolve(data ? JSON.parse(data) : {}); } catch (e) { reject(e); }
    });
  });
}

function getToken(req) {
  const auth = req.headers.authorization || '';
  if (auth.startsWith('Bearer ')) return auth.slice(7);
  return null;
}

async function handler(req, res) {
  await storeReady;
  const url = new URL(req.url, `http://${req.headers.host}`);
  const path = url.searchParams.get('r') || url.pathname.replace(/\/$/, '');
  const method = req.method;

  // CORS preflight
  if (method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    });
    res.end();
    return;
  }

  try {
    // ---------- LOGIN ----------
    if (path === '/auth/login' && method === 'POST') {
      const { identifier, password } = await getBody(req);
      if (!identifier || !password) return json(res, 400, { message: 'يرجى إدخال اسم المستخدم وكلمة المرور' });

      const user = findUserByEmailOrUsername(identifier);
      if (!user) return json(res, 401, { message: 'بيانات تسجيل الدخول غير صحيحة' });
      if (user.is_banned) return json(res, 403, { message: 'حسابك محظور' });

      const valid = await verifyPassword(password, user.password_hash);
      if (!valid) return json(res, 401, { message: 'بيانات تسجيل الدخول غير صحيحة' });

      const token = signJwt({ userId: user.id, role: user.role });
      return json(res, 200, {
        token,
        user: publicUser(user),
        message: 'تم تسجيل الدخول بنجاح',
      });
    }

    // ---------- REGISTER ----------
    if (path === '/auth/register' && method === 'POST') {
      const { full_name, username, email, password } = await getBody(req);
      if (!full_name || !username || !email || !password) {
        return json(res, 400, { message: 'جميع الحقول مطلوبة' });
      }
      if (password.length < 6) return json(res, 400, { message: 'كلمة المرور قصيرة جداً (6 أحرف على الأقل)' });

      if (store.users.some(u => u.email === email)) return json(res, 409, { message: 'البريد الإلكتروني مستخدم بالفعل' });
      if (store.users.some(u => u.username === username)) return json(res, 409, { message: 'اسم المستخدم مستخدم بالفعل' });

      const password_hash = await hashPassword(password);
      const newUser = {
        id: 'u-' + crypto.randomBytes(4).toString('hex'),
        email, username, full_name, role: 'user',
        password_hash, xp: 0, level: 1, vip_level: 'free',
        created_at: new Date().toISOString(),
      };
      store.users.push(newUser);

      const token = signJwt({ userId: newUser.id, role: newUser.role });
      return json(res, 201, {
        token, user: publicUser(newUser),
        message: 'تم إنشاء الحساب بنجاح',
      });
    }

    // ---------- LOGOUT ----------
    if (path === '/auth/logout' && method === 'POST') {
      return json(res, 200, { message: 'تم تسجيل الخروج' });
    }

    // ---------- ME ----------
    if (path === '/auth/me' && method === 'GET') {
      const token = getToken(req);
      if (!token) return json(res, 401, { message: 'غير مصرح' });
      const payload = verifyJwt(token);
      if (!payload) return json(res, 401, { message: 'جلسة غير صالحة' });
      const user = findUserById(payload.userId);
      if (!user) return json(res, 404, { message: 'المستخدم غير موجود' });
      if (user.is_banned) return json(res, 403, { message: 'حسابك محظور' });
      return json(res, 200, { user: publicUser(user) });
    }

    return json(res, 404, { message: 'نقطة النهاية غير موجودة' });
  } catch (e) {
    console.error('[auth]', e);
    return json(res, 500, { message: 'خطأ في الخادم' });
  }
}

module.exports = { handler };
