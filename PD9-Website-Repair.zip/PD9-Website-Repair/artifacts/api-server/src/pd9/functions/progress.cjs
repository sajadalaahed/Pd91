/* ============================================
   PD9 - Netlify Function: progress
   Endpoints:
     GET  /progress
     POST /progress
   ============================================ */

const { verifyJwt, store, getCaseProgress, storeReady } = require('../lib/store.cjs');

function json(res, status, body) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.end(JSON.stringify(body));
}

function getToken(req) {
  const auth = req.headers.authorization || '';
  return auth.startsWith('Bearer ') ? auth.slice(7) : null;
}

async function handler(req, res) {
  await storeReady;
  const url = new URL(req.url, `http://${req.headers.host}`);
  const path = url.searchParams.get('r') || url.pathname.replace(/\/$/, '');
  const method = req.method;

  if (method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    });
    res.end();
    return;
  }

  try {
    const token = getToken(req);
    if (!token) return json(res, 401, { message: 'تسجيل الدخول مطلوب' });
    const payload = verifyJwt(token);
    if (!payload) return json(res, 401, { message: 'جلسة غير صالحة' });

    // ---------- GET /progress ----------
    if (path === '/progress' && method === 'GET') {
      const userProgress = store.progress.filter(p => p.userId === payload.userId);
      // Map caseId -> progress
      const out = {};
      userProgress.forEach(p => { out[p.caseId] = p; });
      return json(res, 200, { progress: out });
    }

    // ---------- POST /progress ----------
    if (path === '/progress' && method === 'POST') {
      let body;
      try { body = JSON.parse(await new Promise(r => { let d=''; req.on('data',c=>d+=c); req.on('end',()=>r(d)); })); } catch { return json(res,400,{message: 'بيانات غير صالحة'}); }

      const {
        case_id,
        current_stage,
        completed_stages,
        collected_evidence,
        total_xp,
        case_completed,
        case_result,
      } = body;

      let prog = getCaseProgress(payload.userId, case_id);
      if (!prog) {
        prog = { userId: payload.userId, caseId: case_id, current_stage: 1, completed_stages: [], collected_evidence: [], total_xp: 0 };
        store.progress.push(prog);
      }
      if (current_stage !== undefined) prog.current_stage = current_stage;
      if (completed_stages) prog.completed_stages = completed_stages;
      if (collected_evidence) prog.collected_evidence = collected_evidence;
      if (total_xp !== undefined) prog.total_xp = total_xp;
      if (case_completed !== undefined) prog.case_completed = case_completed;
      if (case_result) prog.case_result = case_result;

      return json(res, 200, { message: 'تم حفظ التقدم', progress: prog });
    }

    return json(res, 404, { message: 'نقطة النهاية غير موجودة' });
  } catch (e) {
    console.error('[progress]', e);
    return json(res, 500, { message: 'خطأ في الخادم' });
  }
}

module.exports = { handler };
